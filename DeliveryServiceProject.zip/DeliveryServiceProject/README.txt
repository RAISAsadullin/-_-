Проект службы доставки на Java

В каталоге находятся модули:
Main.java
ConsoleMenu.java
OrderService.java
Order.java
OrderItem.java
Client.java
Courier.java
OrderStatus.java
Delivery.java
CourierDelivery.java
ExpressDelivery.java
SelfDelivery.java

Варианты доставки в меню:
Стандартная доставка курьером: 5.0, срок послезавтра.
Экспресс-доставка: 12.0, срок сегодня.
Самовывоз: 0.0, готовность завтра.

Команды главного меню: CREATE, SHOW, EDIT, START, EXIT.
После успешного START программа выводит информацию о доставке и завершает работу.
Данные хранятся в памяти и очищаются после завершения программы.

Файл PostDelivery.java от предыдущего варианта больше не используется. Его можно удалить из IntelliJ или оставить, если он не используется в меню.

Для запуска используйте Main.java.
