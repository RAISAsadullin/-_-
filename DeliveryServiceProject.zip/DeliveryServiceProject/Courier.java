public class Courier {
    private String name;
    private String phone;

    public Courier(String name, String phone) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Введите имя курьера.");
        }
        if (phone == null || phone.isBlank()) {
            throw new IllegalArgumentException("Введите телефон курьера.");
        }
        this.name = name.trim();
        this.phone = phone.trim();
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }
}
